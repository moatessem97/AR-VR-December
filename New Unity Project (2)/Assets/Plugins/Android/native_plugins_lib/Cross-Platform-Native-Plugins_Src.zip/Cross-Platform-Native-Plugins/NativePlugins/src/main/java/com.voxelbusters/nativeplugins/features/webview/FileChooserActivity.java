package com.voxelbusters.nativeplugins.features.webview;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.ResultReceiver;

import com.voxelbusters.nativeplugins.defines.Keys;

public class FileChooserActivity extends Activity
{
    public static final int		REQUEST_CODE_UNKNOWN            = -1;
    public static final int		REQUEST_CODE_FILE_CHOOSER       = 111;
    private String currentAction = "";
    private ResultReceiver callback;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        Bundle bundleInfo = intent.getExtras();

        Intent requiredIntent = null;
        int requestCode = REQUEST_CODE_UNKNOWN;


        String type = bundleInfo.getString(Keys.TYPE);

        currentAction = type;


        if (type.equals(Keys.WebView.FILE_CHOOSER))
        {
            requestCode = REQUEST_CODE_FILE_CHOOSER;
            callback = (ResultReceiver) intent.getSerializableExtra(Keys.CALLBACK);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();

        close();
    }

    void close()
    {
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent)
    {
        super.onActivityResult(requestCode, resultCode, intent);
        switch (requestCode)
        {
            case REQUEST_CODE_FILE_CHOOSER:

                if (resultCode == RESULT_OK && intent != null)
                {
                    if (callback != null)
                    {
                        Bundle bundle = new Bundle();
                        bundle.putParcelable("DATA", intent.getData());
                        callback.send(0, bundle);
                    }
                }
                callback = null;
                break;
        }
        finish();
    }
}
