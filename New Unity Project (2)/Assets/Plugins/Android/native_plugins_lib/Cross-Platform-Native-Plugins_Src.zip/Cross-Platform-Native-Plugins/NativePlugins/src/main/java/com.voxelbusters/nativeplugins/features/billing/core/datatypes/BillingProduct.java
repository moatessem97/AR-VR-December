package com.voxelbusters.nativeplugins.features.billing.core.datatypes;

import com.google.gson.JsonObject;

/**
 * Created by ayyappa on 28/03/16.
 */
public class BillingProduct
{
    public String   name;
    public String   description;
    public String   product_identifier;
    public long     price_amount_micros;
    public String   localised_price;
    public String   currency_code;
    public String   currency_symbol;

    public  JsonObject getJsonObject()
    {
        JsonObject jsonObject = new JsonObject();

        jsonObject.addProperty("name",name);
        jsonObject.addProperty("description",description);
        jsonObject.addProperty("product-identifier",product_identifier);
        jsonObject.addProperty("price-amount-micros",price_amount_micros);
        jsonObject.addProperty("localised-price",localised_price);
        jsonObject.addProperty("currency-code",currency_code);
        jsonObject.addProperty("currency-symbol",currency_symbol);

        return  jsonObject;
    }
}


