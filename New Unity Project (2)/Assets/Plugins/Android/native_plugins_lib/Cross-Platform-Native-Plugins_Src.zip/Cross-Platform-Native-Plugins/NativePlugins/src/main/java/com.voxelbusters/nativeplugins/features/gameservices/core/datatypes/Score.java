package com.voxelbusters.nativeplugins.features.gameservices.core.datatypes;

import com.voxelbusters.nativeplugins.defines.Keys;

import java.util.HashMap;
import java.util.Objects;

/**
 * Created by ayyappa on 11/05/16.
 */
public class Score
{
    public String                   identifier;
    public User                     user;
    public long                     value;
    public long                     date;
    public String                   formattedValue;
    public long                     rank;

    public HashMap<String, Object> getHashMap()
    {
        HashMap<String, Object> hash = new HashMap<String, Object>();
        hash.put(Keys.GameServices.SCORE_ID, identifier);

        if (user != null)
        {
            hash.put(Keys.GameServices.SCORE_USER, user.getHashMap());
        }

        hash.put(Keys.GameServices.SCORE_VALUE, value);
        hash.put(Keys.GameServices.SCORE_DATE, date);
        hash.put(Keys.GameServices.SCORE_FORMATTED_VALUE, formattedValue);
        hash.put(Keys.GameServices.SCORE_RANK, rank);

        return hash;
    }
}
