package com.voxelbusters.nativeplugins.features.billing.serviceprovider.amazon;

import com.amazon.device.iap.internal.model.ReceiptBuilder;
import com.amazon.device.iap.model.ProductType;
import com.amazon.device.iap.model.PurchaseResponse;
import com.amazon.device.iap.model.Receipt;
import com.amazon.device.iap.model.RequestId;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.features.billing.core.datatypes.BillingTransaction;
import com.voxelbusters.nativeplugins.features.billing.core.interfaces.IBillingServiceListener;
import com.voxelbusters.nativeplugins.utilities.Debug;
import com.voxelbusters.nativeplugins.utilities.StringUtility;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 * Created by ayyappa on 20/05/16.
 */
public class AmazonBillingHelper
{

    public class Requests
    {
        public final String BUY_PRODUCT_REQUEST             = "buy-product-request";
        public final String RESTORE_PURCHASES_REQUEST       = "restore-purchases-request";
        public final String REQUEST_PRODUCT_DATA_REQUEST    = "request-product-data-request";
    }

    static HashMap<String, String> requestMap = new HashMap<String, String>();

    public static BillingTransaction getBillingTransaction(Receipt receipt, PurchaseResponse.RequestStatus status, String error)
    {
        BillingTransaction transaction = new BillingTransaction();

        transaction.productIdentifier 		= receipt.getSku();
        transaction.rawPurchaseData 		= receipt.getReceiptId(); // TODO
        transaction.transactionDate 		= receipt.getPurchaseDate().getTime();
        transaction.transactionState 		= getTransactionState(status);
        transaction.verificationState 		= Keys.Billing.Validation.DIDNT_VALIDATE;
        transaction.error 					= error;
        transaction.transactionReceipt 		= receipt.getReceiptId(); // TODO
        transaction.transactionIdentifier 	= receipt.getReceiptId(); // TODO

        return  transaction;
    }

    public static String getTransactionState(PurchaseResponse.RequestStatus purchaseState)
    {
        String state = Keys.Billing.PurchaseState.FAILED;

        if (PurchaseResponse.RequestStatus.FAILED == purchaseState ||
                PurchaseResponse.RequestStatus.NOT_SUPPORTED == purchaseState ||
                PurchaseResponse.RequestStatus.INVALID_SKU == purchaseState)
        {
            state = Keys.Billing.PurchaseState.FAILED;
        }
        else if(PurchaseResponse.RequestStatus.SUCCESSFUL == purchaseState || PurchaseResponse.RequestStatus.ALREADY_PURCHASED == purchaseState)
        {
            state =  Keys.Billing.PurchaseState.PURCHASED;
        }

        return state;
    }

    public static void reportFailedTransaction(String productId, String error, IBillingServiceListener listener)
    {
        if (listener != null)
        {
            ReceiptBuilder receiptBuilder = new ReceiptBuilder();
            receiptBuilder.setProductType(ProductType.ENTITLED);
            receiptBuilder.setReceiptId(null);
            receiptBuilder.setSku(productId);
            receiptBuilder.setPurchaseDate(new Date(0));

            Receipt receipt = receiptBuilder.build();
            ArrayList<BillingTransaction> list = new ArrayList<BillingTransaction>();
            list.add(getBillingTransaction(receipt, PurchaseResponse.RequestStatus.FAILED,  error));
            listener.onPurchaseTransactionFinished(list, null);
        }
    }

    public static void AddBuyRequest(String requestId, String productIdentifier)
    {
        Debug.log(CommonDefines.BILLING_TAG, "AddBuyRequest : Request Id : " + requestId + " " + "ProductIdentifier :" + productIdentifier);
        requestMap.put(requestId, productIdentifier);
    }

    public static void RemoveBuyRequest(String requestId)
    {
        requestMap.remove(requestId);
    }

    public static String GetProductIdentifierForRequest(String requestId)
    {
        String productId = "";
        if (requestMap.containsKey(requestId))
        {
            productId = requestMap.get(requestId);
        }

        Debug.log(CommonDefines.BILLING_TAG, "GetProductIdentifierForRequest : Request Id : " + requestId + " " + "ProductIdentifier :" + productId);

        return productId;
    }

}
